function V = bingen(n)
%BINGEN Enumera todos los vectores binarios como filas, desde 0.
% Funcion auxiliar incluida con este proyecto; no requiere toolbox.
validateattributes(n, {'numeric'}, ...
    {'scalar','integer','>=',1,'<=',16});
V = double(dec2bin(0:(2^n-1), n)) - double('0');
end
