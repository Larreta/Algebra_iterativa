%% ML.2 - Matriz de Hilbert
clear; clc;
H = hilb(5); % El punto y coma evita la salida automatica.
%% (a) Tamano
size(H)
%% (b) Contenido decimal
format short
H
%% (c) Presentacion racional
% Es presentacion racional de numeros double; no exige sym.
format rat
H
%% (d) Todas las filas y las tres primeras columnas
primeras_tres_columnas = H(:,1:3)
%% (e) Dos ultimas filas y todas las columnas
ultimas_dos_filas = H(end-1:end,:)
format short
% Ejemplo de la regla exacta que define las entradas:
fprintf('H(2,3) = 1/(2+3-1) = %.4f\n', H(2,3));
