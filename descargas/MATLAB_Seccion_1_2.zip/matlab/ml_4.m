%% ML.4 - Las 16 matrices binarias de 2 por 2
clear; clc;
V = bingen(4); % Cuatro entradas independientes, no dos.
M = zeros(2,2,16);
for k = 1:size(V,1)
    % V(k,:) = [a11 a12 a21 a22], lectura por filas.
    % reshape rellena por columnas: transponemos para conservar filas.
    M(:,:,k) = reshape(V(k,:),2,2).';
    fprintf('Matriz %d de 16\n', k);
    disp(M(:,:,k));
end
assert(size(M,3)==16);
