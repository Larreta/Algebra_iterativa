function simular_capitulo_1_2
%SIMULAR_CAPITULO_1_2 Laboratorios visuales ML.1 a ML.5.
% Abre esta carpeta como Current Folder de MATLAB y ejecuta:
%   simular_capitulo_1_2
% Requiere los archivos bingen.m y binadd.m entregados aqui.
% No requiere Symbolic Math Toolbox ni Simulink.
t = [];
f = figure('Name','Seccion 1.2 - Simulacion MATLAB', ...
    'NumberTitle','off','Color',[0.96 0.97 0.98], ...
    'Position',[100 100 1150 720], ...
    'CloseRequestFcn',@cerrar);
modo = uicontrol(f,'Style','popupmenu','Units','normalized', ...
    'Position',[0.04 0.91 0.42 0.05], ...
    'String',{'ML.1 Entradas y formatos','ML.2 Hilbert', ...
    'ML.3 Vectores binarios','ML.4 Matrices binarias', ...
    'ML.5 Suma binaria'},'FontSize',12,'Callback',@reiniciarModo);
opcion = uicontrol(f,'Style','popupmenu','Units','normalized', ...
    'Position',[0.52 0.91 0.42 0.05], ...
    'String',{'short','long','rat'}, ...
    'FontSize',12,'Callback',@cambiarOpcion);
ax = gobjects(1,3);
for j = 1:3
    ax(j) = axes('Parent',f,'Units','normalized', ...
        'Position',[0.04+(j-1)*0.32 0.32 0.27 0.50]);
end
barra = uicontrol(f,'Style','slider','Units','normalized', ...
    'Position',[0.10 0.20 0.80 0.035], ...
    'Min',0,'Max',5,'Value',0,'Callback',@(~,~)dibujar());
uicontrol(f,'Style','pushbutton','Units','normalized', ...
    'Position',[0.12 0.10 0.20 0.055], ...
    'String','Siguiente','FontSize',12, ...
    'Callback',@(~,~)avanzar());
play = uicontrol(f,'Style','togglebutton','Units','normalized', ...
    'Position',[0.40 0.10 0.20 0.055], ...
    'String','Reproducir','FontSize',12,'Callback',@reproducir);
uicontrol(f,'Style','pushbutton','Units','normalized', ...
    'Position',[0.68 0.10 0.20 0.055], ...
    'String','Reiniciar','FontSize',12, ...
    'Callback',@(~,~)reiniciarModo());
mensaje = uicontrol(f,'Style','text','Units','normalized', ...
    'Position',[0.04 0.01 0.92 0.075], ...
    'BackgroundColor',[0.96 0.97 0.98], ...
    'HorizontalAlignment','left','FontSize',11);
t = timer('ExecutionMode','fixedSpacing','Period',0.9, ...
    'TimerFcn',@(~,~)avanzar());
reiniciarModo();

    function detener()
        if ~isempty(t) && isvalid(t), stop(t); end
        if isgraphics(play)
            set(play,'Value',0,'String','Reproducir');
        end
    end

    function reiniciarModo(varargin)
        detener();
        switch get(modo,'Value')
            case 1, nombres = {'short','long','rat'};
            case 2
                nombres = {'H completo','Tres primeras columnas', ...
                    'Dos ultimas filas','H en fracciones'};
            case 3, nombres = {'3 coordenadas','4 coordenadas'};
            case 4, nombres = {'Todas las matrices de 2 por 2'};
            case 5
                nombres = {'(a) A+B','(b) B+C','(c) A+B+C', ...
                    '(d) A+transpuesta(C)','(e) B-C'};
        end
        set(opcion,'String',nombres,'Value',1);
        cambiarOpcion();
    end

    function cambiarOpcion(varargin)
        detener();
        switch get(modo,'Value')
            case 1, maximo = 5;
            case 2, maximo = 24;
            case 3, maximo = 2^(get(opcion,'Value')+2)-1;
            case 4, maximo = 15;
            case 5, maximo = 8;
        end
        set(barra,'Max',maximo,'Value',0, ...
            'SliderStep',[1/maximo min(1,4/maximo)]);
        dibujar();
    end

    function avanzar()
        if ~isgraphics(f), return; end
        k = mod(round(get(barra,'Value'))+1,get(barra,'Max')+1);
        set(barra,'Value',k); dibujar();
    end

    function reproducir(varargin)
        if get(play,'Value')
            set(play,'String','Pausar'); start(t);
        else
            detener();
        end
    end

    function dibujar()
        k = round(get(barra,'Value')); set(barra,'Value',k);
        q = get(opcion,'Value'); m = get(modo,'Value');
        formato = 'short'; seleccion = [];
        switch m
            case 1
                L = [5 1 2;-3 0 1;2 4 1];
                M = [4*2 2/3;1/201 5-8.2;0.00001 (9+4)/3];
                i = floor(k/2)+1; j = mod(k,2)+1;
                R = M(i,j); seleccion = [i j];
                formatos = {'short','long','rat'};
                formato = formatos{q};
                nombres = {'A','B','Entrada de B elegida'};
                msg = {sprintf('B(%d,%d) = %.15g. A(2,3)=1.', ...
                    i,j,R), ...
                    'B(2,3) NO existe: B solo tiene 2 columnas.'};
            case 2
                L = hilb(5); i = floor(k/5)+1; j = mod(k,5)+1;
                seleccion = [i j]; R = L(i,j);
                switch q
                    case 1, M = L;
                    case 2, M = L(:,1:3);
                    case 3, M = L(end-1:end,:);
                    case 4, M = L; formato = 'rat';
                end
                nombres = {'H = hilb(5)','Seleccion de H','H(i,j)'};
                msg = {sprintf('i=%d, j=%d: H(i,j)=1/%d.', ...
                    i,j,i+j-1), ...
                    'El punto y coma suprime salida, no la variable.'};
            case 3
                n = q+2; L = bingen(n); M = L(k+1,:); R = k;
                nombres = {'Todos los vectores','Vector elegido', ...
                    'Indice decimal (desde 0)'};
                msg = {sprintf('Vector %d de %d, longitud %d.', ...
                    k+1,2^n,n), ...
                    'Cada fila es distinta. Hay dos elecciones por bit.'};
            case 4
                L = bingen(4); M = L(k+1,:);
                R = reshape(M,2,2).';
                nombres = {'Los 16 vectores de 4 bits', ...
                    '[a11 a12 a21 a22]','Matriz 2 por 2'};
                msg = {sprintf('Matriz %d de 16.',k+1), ...
                    'Leemos por filas: reshape(V,2,2).'' conserva ese orden.'};
            case 5
                A = [1 0 1;1 1 0;0 1 1];
                B = [0 1 1;1 0 1;1 1 0];
                C = [1 1 0;0 1 1;1 0 1];
                switch q
                    case 1, L=A; M=B;
                    case 2, L=B; M=C;
                    case 3, L=binadd(A,B); M=C;
                    case 4, L=A; M=C.';
                    case 5, L=B; M=C;
                end
                R=binadd(L,M); i=floor(k/3)+1; j=mod(k,3)+1;
                seleccion=[i j];
                nombres={'Primer operando','Segundo operando', ...
                    'Resultado modulo 2'};
                msg={sprintf('Casilla (%d,%d): (%d+%d) mod 2 = %d.', ...
                    i,j,L(i,j),M(i,j),R(i,j)), ...
                    'En modulo 2, restar es sumar: 1+1 se reduce a 0.'};
        end
        pintar(ax(1),L,nombres{1},formato,seleccion);
        pintar(ax(2),M,nombres{2},formato,seleccion);
        pintar(ax(3),R,nombres{3},formato,seleccion);
        set(mensaje,'String',msg); drawnow limitrate;
    end

    function pintar(a,X,nombre,formato,sel)
        cla(a); imagesc(a,X); axis(a,'image');
        colormap(a,[0.88 0.94 0.99;0.27 0.55 0.78]);
        [nr,nc]=size(X);set(a,'XTick',1:nc,'YTick',1:nr);
        title(a,nombre,'Interpreter','none','FontSize',11);
        for ii=1:nr
            for jj=1:nc
                if strcmp(formato,'rat')
                    txt=strtrim(rats(X(ii,jj)));
                elseif all(X(:)==fix(X(:)))
                    txt=sprintf('%.0f',X(ii,jj));
                elseif strcmp(formato,'long')
                    txt=sprintf('%.15f',X(ii,jj));
                else
                    txt=sprintf('%.4f',X(ii,jj));
                end
                text(a,jj,ii,txt,'HorizontalAlignment','center', ...
                    'FontSize',max(8,13-floor(nr/3)), ...
                    'Color',[0.05 0.10 0.15], ...
                    'Interpreter','none');
            end
        end
        if ~isempty(sel) && sel(1)<=nr && sel(2)<=nc
            hold(a,'on');rectangle(a, ...
                'Position',[sel(2)-0.45 sel(1)-0.45 0.9 0.9], ...
                'EdgeColor',[0.85 0.35 0.10],'LineWidth',2);
            hold(a,'off');
        end
    end

    function cerrar(varargin)
        detener();
        if ~isempty(t) && isvalid(t), delete(t); end
        delete(f);
    end
end
