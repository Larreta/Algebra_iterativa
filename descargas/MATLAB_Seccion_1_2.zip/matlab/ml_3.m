%% ML.3 - Todos los vectores binarios de longitudes 3 y 4
clear; clc;
% bingen.m se entrega en esta misma carpeta.
V3 = bingen(3)
V4 = bingen(4)
fprintf('Vectores de longitud 3: %d\n', size(V3,1));
fprintf('Vectores de longitud 4: %d\n', size(V4,1));
assert(isequal(size(V3),[8 3]));
assert(isequal(size(V4),[16 4]));
assert(size(unique(V4,'rows'),1)==16);
