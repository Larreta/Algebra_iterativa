function C = binadd(A, B)
%BINADD Suma binaria entrada a entrada, modulo 2.
% Se incluye porque no se presupone la funcion del material del libro.
assert(isequal(size(A), size(B)), 'Los tamanos deben coincidir.');
assert(all(A(:)==0 | A(:)==1), 'A debe ser binaria.');
assert(all(B(:)==0 | B(:)==1), 'B debe ser binaria.');
C = mod(double(A) + double(B), 2);
end
