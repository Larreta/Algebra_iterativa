%% ML.1 - Entradas, filas, columnas y formatos
clear; clc;
A = [5 1 2; -3 0 1; 2 4 1];
B = [4*2 2/3; 1/201 5-8.2; 0.00001 (9+4)/3];
%% (a) Primer indice: fila; segundo indice: columna
fprintf('a23 = %.15g\n', A(2,3));
% El enunciado pide b23, pero B solo tiene DOS columnas.
if size(B,2) < 3
    disp('b23 no existe: B tiene 3 filas y 2 columnas.');
else
    disp(B(2,3));
end
fprintf('b12 = %.15g\n', B(1,2));
%% (b) Dos puntos significa: tomar todas las posiciones
fila1_A = A(1,:)
columna3_A = A(:,3)
fila2_B = B(2,:)
%% (c) Cambiar el formato no cambia los valores almacenados
B_guardada = B;
format long
B
format short
B
assert(isequal(B, B_guardada));
fprintf('b12 con 15 decimales: %.15f\n', B(1,2));
fprintf('b12 con 4 decimales: %.4f\n', B(1,2));
format short
