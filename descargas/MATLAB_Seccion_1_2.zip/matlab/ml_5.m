%% ML.5 - Ejercicio 11 con binadd (modulo 2)
clear; clc;
A = [1 0 1; 1 1 0; 0 1 1];
B = [0 1 1; 1 0 1; 1 1 0];
C = [1 1 0; 0 1 1; 1 0 1];
%% (a) A+B
Ra = binadd(A,B)
%% (b) B+C
Rb = binadd(B,C)
%% (c) A+B+C
Rc = binadd(binadd(A,B),C)
%% (d) A+transpuesta(C), sin conjugacion
Rd = binadd(A,C.')
%% (e) En modulo 2, restar y sumar coinciden
Re = binadd(B,C)
assert(isequal(Re, mod(B-C,2)));
assert(isequal(Ra, [1 1 0;0 1 1;1 0 1]));
assert(isequal(Rb, [1 0 1;1 1 0;0 1 1]));
assert(isequal(Rc, zeros(3)));
format short
