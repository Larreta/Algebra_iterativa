# Sección 1.2 en MATLAB

1. Extrae todos estos archivos en una misma carpeta.
2. En MATLAB, abre esa carpeta como **Current Folder**.
3. Para ver las soluciones por comandos, ejecuta `ml_1`, `ml_2`, `ml_3`, `ml_4` o `ml_5`.
4. Para la ventana interactiva, ejecuta `simular_capitulo_1_2`.
5. Elige ML.1–ML.5 arriba. Mueve la barra, pulsa Siguiente o Reproducir. Reiniciar vuelve al primer caso; cerrar elimina el temporizador.

`bingen.m` y `binadd.m` son implementaciones auxiliares entregadas con este proyecto. No se supone que sean funciones incorporadas de MATLAB. Mantén ambos archivos junto a los ejercicios. No hace falta Symbolic Math Toolbox ni Simulink.

En ML.1, **b23 no existe** para la B de 3 filas y 2 columnas que aparece en la imagen del enunciado. El script lo señala y continúa. No se ha sustituido ese índice por otro.

En los ejercicios binarios se opera módulo 2. `binadd` usa `mod(A+B,2)`, con comprobación explícita de dimensiones y de entradas binarias. En MATLAB moderno la expansión implícita puede permitir operaciones sobre ciertos tamaños distintos; este material exige el mismo tamaño, como establece la suma matricial del libro.

La web integra una simulación didáctica en JavaScript de los mismos datos y operaciones. No ejecuta MATLAB ni envía comandos a una instalación remota. La ventana de `simular_capitulo_1_2.m` se ejecuta en tu MATLAB. Se han contrastado los resultados con aritmética exacta en Python; no se dispone de una licencia o proceso MATLAB en el entorno de preparación.

Documentación oficial consultada:
- https://www.mathworks.com/help/matlab/ref/hilb.html
- https://www.mathworks.com/help/matlab/ref/format.html
- https://www.mathworks.com/help/matlab/ref/double.transpose.html
- https://www.mathworks.com/help/matlab/ref/double.mod.html
- https://www.mathworks.com/help/matlab/ref/uicontrol.html
- https://www.mathworks.com/help/matlab/ref/timer.html
